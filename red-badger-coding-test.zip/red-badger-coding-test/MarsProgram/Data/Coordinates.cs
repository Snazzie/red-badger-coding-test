namespace MarsProgram.Data;

public record Coordinates(int X, int Y);