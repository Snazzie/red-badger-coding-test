﻿namespace MarsProgram.Data;

public record GridSize(int X, int Y);