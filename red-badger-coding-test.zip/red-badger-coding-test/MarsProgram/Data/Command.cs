namespace MarsProgram.Data;

public enum Command
{
    L,
    R,
    F
}